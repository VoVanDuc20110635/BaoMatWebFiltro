package com.data.filtro.config;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;


public class XFrameOptionsInterceptor  implements HandlerInterceptor {
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        response.setHeader("X-Frame-Options", "SAMEORIGIN");
        response.setHeader("Content-Security-Policy", "script-src 'self' https://code.jquery.com " +
                "https://kit.fontawesome.com " +
                "https://unpkg.com " +
                "https://cdn.jsdelivr.net ; " +
                "frame-src 'self';");
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        // Mã logic xử lý sau khi xử lý yêu cầu nhưng trước khi hiển thị kết quả (post-processing)
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        // Mã logic xử lý sau khi hoàn thành xử lý yêu cầu (clean-up tasks)
//        HttpSession session = request.getSession(false);
//        if (session != null) {
//            Cookie cookie = WebUtils.getCookie(request, session.getId());
//            if (cookie != null) {
//                cookie.setSameSite("Lax");
//                response.addCookie(cookie);
//            }
//        }
    }
}
